class InvalidEmailException(Exception): pass
class NegativeSalaryException(Exception): pass
class ResumeFileException(Exception): pass
class DeadlinePassedException(Exception): pass
class DBConnectionException(Exception): pass
